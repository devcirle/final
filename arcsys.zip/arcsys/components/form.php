<main>
        <div class="center">
          <button id="show-login">Create New</button>
        </div>
        <div class="popup">
          <div class="close-btn">&times;</div>
          <div class="form">
            <h2>Create New</h2>
            <div class="form-element">
              <label for="email">Type of Species:</label>
              <input
                type="text"
                id="email"
                placeholder="Enter name of species"
              />
            </div>
            <div class="form-element">
              <label for="temp">Temperature:</label>
              <input type="text" id="temp" placeholder="Enter temperature" />
            </div>
            <div class="form-element">
              <button>Save</button>
            </div>
          </div>
        </div>
      </main>