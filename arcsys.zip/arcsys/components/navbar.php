<div class="sidebar">

  <a href="../views/index.php" class="active">
    <span class="material-symbols-outlined"> dashboard </span>
    <h3>Dashboard</h3>
  </a>

  <a href="../views/control.php">
    <span class="material-symbols-outlined"> valve </span>
    <h3>Control</h3>
  </a>

  <a href="../views/data.php">
    <span class="material-symbols-outlined"> monitoring </span>
    <h3>Data</h3>
  </a>

  <a href="../views/notification.php">
    <span class="material-symbols-outlined"> notifications </span>
    <h3>Notifications</h3>
  </a>

  <a href="../views/customize.php">
    <span class="material-symbols-outlined"> settings </span>
    <h3>Customize</h3>
  </a>

  <a href="../views/about.php">
    <span class="material-symbols-outlined"> info </span>
    <h3>About</h3>
  </a>

  <a href="#">
    <span class="material-symbols-outlined"> logout </span>
    <h3>Logout</h3>
  </a>
  
</div>